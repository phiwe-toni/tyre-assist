# Tyre Assist - Complete Road Assistance Platform

## What it is
A comprehensive Tyre Assist application (Flask) with user and worker authentication, payment processing, AI customer service chatbot, and real-time navigation. Users can request tyre assistance, workers can navigate to customers, and payments are processed securely.

## Features

### 🔐 Authentication System
- Separate sign up/sign in for **Users** and **Workers**
- Secure password hashing with Werkzeug
- Session-based authentication
- Protected routes for worker dashboard

### 💳 Payment Gateway
- **Online Payment**: Credit/debit card processing (simulated)
- **Cash on Delivery**: Payment collected when worker arrives
- Payment validation and secure processing
- Payment tracking and status management

### 🤖 AI Customer Service (tyreBot)
- Intelligent chatbot for customer assistance
- Answers questions about services, pricing, payment, and location
- Real-time chat interface
- Context-aware responses

### 🗺️ Navigation System
- Real-time route calculation between worker and customer
- Interactive maps with Leaflet.js
- Distance and time estimation
- Turn-by-turn directions

### 👷 Worker Dashboard
- View pending requests
- Accept and manage jobs
- Navigate to customer locations
- Update request status (pending → assigned → in-progress → completed)
- View payment information for each request

### 📱 User Features
- Request tyre assistance with location picking
- Choose payment method (online or cash)
- Track request status
- Chat with tyreBot for assistance

## What's included
- Modernised UI with responsive layout
- Leaflet-powered interactive maps
- Authentication system (users and workers)
- Payment gateway integration
- AI chatbot (tyreBot)
- Worker dashboard with navigation
- Production-ready deployment files

## How to Run This App
1. (Optional) Create a Python virtual environment:
   ```bash
   python -m venv venv
   # On Windows:
   venv\Scripts\activate
   # On Mac/Linux:
   source venv/bin/activate
   ```
2. Install the requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. Start the Flask app:
   ```bash
   python app.py
   ```
4. Open your browser at [http://127.0.0.1:5000](http://127.0.0.1:5000) and interact with the full app.

## Deploying to Heroku (recommended)
1. Install the [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli) and run `heroku login`.
2. From the project root:
   ```bash
   heroku create tyre-assist-demo   # choose your own unique name
   git add .
   git commit -m "Prepare Tyre Assist for deployment"
   git push heroku main             # or master depending on your branch
   ```
3. Scale the dyno on first deploy:
   ```bash
   heroku ps:scale web=1
   ```
4. Visit your app with `heroku open`.

> ℹ️ `requests.json` lives on Heroku’s ephemeral filesystem, so data resets on dyno restarts. Add a managed database (Heroku Postgres, MongoDB Atlas, etc.) for production workloads.

## Alternative deployment options
- VPS/server that can run Flask + Gunicorn: `gunicorn -b 0.0.0.0:5000 app:app`
- Container platforms (Render, Railway, Fly.io) using the provided `Procfile`
- Java/Spring Boot version lives under `TyreAssist/` with its own Dockerfile

## Data Storage
- User accounts: `users.json`
- Worker accounts: `workers.json`
- Assistance requests: `requests.json`
- Payment records: `payments.json`

## Security Notes
- Passwords are hashed using Werkzeug's password hashing
- Sessions are used for authentication
- Card details are validated but not stored (simulated payment gateway)
- For production, use a proper database (PostgreSQL, MongoDB) and integrate with real payment gateways (Stripe, PayPal)

## Environment Variables
- `SECRET_KEY`: Flask secret key for sessions (auto-generated if not set)
- `FLASK_DEBUG`: Set to `1`, `true`, or `yes` to enable debug mode

## API Endpoints
See `API_DOCUMENTATION.md` for complete API documentation.

## Deployment
The app is ready for deployment to Heroku, Render, Railway, or any platform supporting Flask applications.
