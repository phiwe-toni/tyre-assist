package com.tyreassist;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Controller
public class TyreAssistController {
    private final List<AssistanceRequest> requests = new CopyOnWriteArrayList<>();

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("requests", requests);
        return "index";
    }

    @PostMapping("/request")
    public String requestAssist(@RequestParam String name, @RequestParam String phone,
                                @RequestParam(required=false) String vehicle, @RequestParam(required=false, name="tyre_size") String tyreSize,
                                @RequestParam(required=false) String notes, @RequestParam String location,
                                RedirectAttributes attrs) {
        AssistanceRequest req = new AssistanceRequest(name, phone, vehicle, tyreSize, notes, location);
        requests.add(req);
        attrs.addFlashAttribute("message", "Request submitted!");
        return "redirect:/";
    }

    @GetMapping("/api/requests")
    @ResponseBody
    public List<AssistanceRequest> apiRequests() {
        return Collections.unmodifiableList(requests);
    }
}
