package com.tyreassist;

public class AssistanceRequest {
    private String name;
    private String phone;
    private String vehicle;
    private String tyreSize;
    private String notes;
    private String location;

    public AssistanceRequest() {}

    public AssistanceRequest(String name, String phone, String vehicle, String tyreSize, String notes, String location) {
        this.name = name;
        this.phone = phone;
        this.vehicle = vehicle;
        this.tyreSize = tyreSize;
        this.notes = notes;
        this.location = location;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getVehicle() { return vehicle; }
    public void setVehicle(String vehicle) { this.vehicle = vehicle; }
    public String getTyreSize() { return tyreSize; }
    public void setTyreSize(String tyreSize) { this.tyreSize = tyreSize; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
}
