package com.tyreassist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TyreAssistApplication {
    public static void main(String[] args) {
        SpringApplication.run(TyreAssistApplication.class, args);
    }
}
