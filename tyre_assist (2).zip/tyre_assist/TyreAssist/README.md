# Tyre Assist (Java Spring Boot version)

## Features
- Web form for tyre assistance requests
- Interactive OpenStreetMap (Leaflet.js) for picking exact location
- Recent requests listed and shown on a map
- Demo POIs: tyre shops and gas stations

## Requirements
- Java 17+
- Maven

## How to Build and Run
```bash
cd TyreAssist
mvn spring-boot:run
```

Then visit [http://localhost:8080](http://localhost:8080)

## Deployment
- Can be deployed to any server supporting Java
- For production: 
  - Build: `mvn package`
  - Deploy resulting JAR

## Project Structure
- `src/main/java/com/tyreassist/AssistanceRequest.java` - domain model
- `src/main/java/com/tyreassist/TyreAssistController.java` - controller/routes
- `src/main/resources/templates/index.html` - Thymeleaf template for UI
- `src/main/resources/static/style.css` - app styles
- `pom.xml` - Maven build file
