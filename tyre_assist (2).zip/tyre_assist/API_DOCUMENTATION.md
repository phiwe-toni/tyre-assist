# Tyre Assist API Documentation

## Overview
This document describes all available API endpoints for the Tyre Assist application, including customer request management and worker navigation features.

## Base URL
- Local: `http://localhost:5000`
- Production: (Your deployment URL)

## API Endpoints

### Customer Requests

#### 1. Get All Requests
**GET** `/api/requests`

Returns all assistance requests sorted by timestamp (newest first).

**Response:**
```json
[
  {
    "id": "uuid-string",
    "name": "John Doe",
    "phone": "1234567890",
    "location": "-29.85,31.02",
    "vehicle": "Toyota Corolla",
    "tyre_size": "205/55 R16",
    "notes": "Flat tyre on front left",
    "timestamp": "2024-01-15T10:30:00",
    "status": "pending"
  }
]
```

#### 2. Get Specific Request
**GET** `/api/requests/<request_id>`

Returns a specific request by ID.

**Response:**
```json
{
  "id": "uuid-string",
  "name": "John Doe",
  "phone": "1234567890",
  "location": "-29.85,31.02",
  "vehicle": "Toyota Corolla",
  "tyre_size": "205/55 R16",
  "notes": "Flat tyre on front left",
  "timestamp": "2024-01-15T10:30:00",
  "status": "pending"
}
```

#### 3. Create Request
**POST** `/request`

Creates a new assistance request. Supports both form data and JSON.

**Form Data:**
- `name` (required): Customer name
- `phone` (required): Phone number
- `location` (required): Coordinates as "lat,lng"
- `vehicle` (optional): Vehicle model
- `tyre_size` (optional): Tyre size
- `notes` (optional): Additional notes

**JSON Example:**
```json
{
  "name": "John Doe",
  "phone": "1234567890",
  "location": "-29.85,31.02",
  "vehicle": "Toyota Corolla",
  "tyre_size": "205/55 R16",
  "notes": "Flat tyre"
}
```

**Response:**
```json
{
  "success": true,
  "request": {
    "id": "uuid-string",
    "name": "John Doe",
    "timestamp": "2024-01-15T10:30:00",
    "status": "pending"
  }
}
```

#### 4. Delete Request
**DELETE** `/api/requests/<request_id>`

Deletes a request by ID.

**Response:**
```json
{
  "success": true
}
```

#### 5. Update Request Status
**PUT/PATCH** `/api/requests/<request_id>/status`

Updates the status of a request. Used by workers to manage request lifecycle.

**Request Body (JSON):**
```json
{
  "status": "assigned",
  "worker_id": "worker-1"
}
```

**Valid Statuses:**
- `pending`: Initial status when request is created
- `assigned`: Request has been accepted by a worker
- `in-progress`: Worker is en route or working on the request
- `completed`: Request has been completed
- `cancelled`: Request was cancelled

**Response:**
```json
{
  "success": true,
  "request": {
    "id": "uuid-string",
    "status": "assigned",
    "worker_id": "worker-1",
    "assigned_at": "2024-01-15T10:35:00"
  }
}
```

#### 6. Get Pending Requests
**GET** `/api/requests/pending`

Returns all requests with status "pending". Used by worker dashboard.

**Response:**
```json
[
  {
    "id": "uuid-string",
    "name": "John Doe",
    "phone": "1234567890",
    "location": "-29.85,31.02",
    "status": "pending",
    "timestamp": "2024-01-15T10:30:00"
  }
]
```

### Navigation APIs

#### 7. Get Route
**GET** `/api/navigation/route`

Calculates route and distance between two points.

**Query Parameters:**
- `start_lat` (required): Starting latitude
- `start_lng` (required): Starting longitude
- `end_lat` (required): Destination latitude
- `end_lng` (required): Destination longitude

**Example:**
```
GET /api/navigation/route?start_lat=-29.85&start_lng=31.02&end_lat=-29.86&end_lng=31.03
```

**Response:**
```json
{
  "distance": 1.23,
  "distance_km": 1.23,
  "distance_miles": 0.76,
  "duration_seconds": 148,
  "duration_minutes": 2.5,
  "waypoints": [
    {"lat": -29.85, "lng": 31.02},
    {"lat": -29.86, "lng": 31.03}
  ],
  "geometry": [
    [31.02, -29.85],
    [31.03, -29.86]
  ],
  "instructions": [
    "Start at -29.85000, 31.02000",
    "Navigate to destination: -29.86000, 31.03000",
    "Estimated distance: 1.23 km",
    "Estimated time: 2.5 minutes"
  ]
}
```

#### 8. Get Directions
**POST** `/api/navigation/directions`

Get turn-by-turn directions between two points.

**Request Body (JSON):**
```json
{
  "start_lat": -29.85,
  "start_lng": 31.02,
  "end_lat": -29.86,
  "end_lng": 31.03
}
```

**Response:**
```json
{
  "start": {"lat": -29.85, "lng": 31.02},
  "end": {"lat": -29.86, "lng": 31.03},
  "distance": 1.23,
  "duration": 2.5,
  "steps": [
    "Start at -29.85000, 31.02000",
    "Navigate to destination: -29.86000, 31.03000",
    "Estimated distance: 1.23 km",
    "Estimated time: 2.5 minutes"
  ]
}
```

## Worker Dashboard

### Access
Navigate to `/worker` in your browser to access the worker dashboard.

### Features
1. **View Pending Requests**: See all requests waiting for assistance
2. **Accept Requests**: Accept and assign requests to yourself
3. **Navigate to Customer**: Get route directions from your location to customer
4. **Update Status**: Mark requests as in-progress or completed
5. **Real-time Updates**: Auto-refreshes every 30 seconds

### Worker Location
- Workers can manually enter their location coordinates
- Use "📍 Use Current Location" button to get GPS coordinates
- Location is used as starting point for navigation

## Error Responses

All endpoints return appropriate HTTP status codes:

- `200 OK`: Request successful
- `201 Created`: Resource created successfully
- `400 Bad Request`: Invalid request parameters
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server error

**Error Response Format:**
```json
{
  "error": "Error message description"
}
```

## Usage Examples

### JavaScript/Fetch Example

```javascript
// Get all requests
const response = await fetch('/api/requests');
const requests = await response.json();

// Create a request
const newRequest = await fetch('/request', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'John Doe',
    phone: '1234567890',
    location: '-29.85,31.02',
    vehicle: 'Toyota Corolla',
    tyre_size: '205/55 R16',
    notes: 'Flat tyre'
  })
});

// Update request status
const updateStatus = await fetch('/api/requests/request-id/status', {
  method: 'PUT',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    status: 'assigned',
    worker_id: 'worker-1'
  })
});

// Get route
const route = await fetch('/api/navigation/route?start_lat=-29.85&start_lng=31.02&end_lat=-29.86&end_lng=31.03');
const routeData = await route.json();
```

### cURL Examples

```bash
# Get all requests
curl http://localhost:5000/api/requests

# Create a request
curl -X POST http://localhost:5000/request \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "phone": "1234567890",
    "location": "-29.85,31.02",
    "vehicle": "Toyota Corolla"
  }'

# Update request status
curl -X PUT http://localhost:5000/api/requests/request-id/status \
  -H "Content-Type: application/json" \
  -d '{
    "status": "assigned",
    "worker_id": "worker-1"
  }'

# Get route
curl "http://localhost:5000/api/navigation/route?start_lat=-29.85&start_lng=31.02&end_lat=-29.86&end_lng=31.03"
```

## Notes

1. **Location Format**: All locations must be in "latitude,longitude" format (e.g., "-29.85,31.02")
2. **Status Flow**: Requests typically flow: `pending` → `assigned` → `in-progress` → `completed`
3. **Route Calculation**: Currently uses Haversine formula for distance calculation. For production, integrate with a routing service (OpenRouteService, Mapbox, Google Directions API)
4. **Worker IDs**: Worker identification is currently simple (e.g., "worker-1"). In production, implement proper authentication
5. **Data Persistence**: Data is stored in `requests.json` file. For production, use a proper database

## Future Enhancements

- Real-time location tracking for workers
- Push notifications for new requests
- Integration with professional routing APIs
- Worker authentication and authorization
- Request prioritization based on distance
- Estimated time of arrival (ETA) calculations
- Multi-worker assignment and coordination

