Local run instructions
======================

This file explains how to run the two apps in this workspace locally.

Flask app (Windows, recommended for quick local testing)
- Create and activate a virtual environment, install requirements, and run with waitress:

```powershell
python -m venv venv
.\venv\Scripts\Activate
pip install -r .\requirements.txt
# To run in debug: set FLASK_DEBUG and run python
# Example: in PowerShell set $env:FLASK_DEBUG='1' then run `python .\app.py`
# Run with waitress (production-like) on Windows
waitress-serve --listen=*:5000 app:app
```

Notes:
- `gunicorn` is included in `requirements.txt` for Linux hosts (Heroku, VPS). Gunicorn does not run on native Windows.

Java Spring Boot app (runs in Docker — no JDK/Maven install required)
- Build and run the Docker image from the `TyreAssist/` folder:

```powershell
cd .\TyreAssist
docker build -t tyreassist-java:local .
docker run --rm -p 8080:8080 tyreassist-java:local
```

If Docker is not available and you prefer to run locally, install JDK 17+ and Maven, then:

```powershell
# Windows (example using Chocolatey):
# choco install temurin17 -y
# choco install maven -y
cd .\TyreAssist
mvn clean package
java -jar .\target\tyreassist-1.0.0.jar
```

Troubleshooting
- If `docker` command is not found, install Docker Desktop for Windows or use WSL2 with Docker.
- If `waitress-serve` is not found, ensure your venv is activated and `waitress` is installed from `requirements.txt`.
