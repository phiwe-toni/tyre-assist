from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os
import uuid
import math
import hashlib
import secrets

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', secrets.token_hex(32))

# Data files
DATA_FILE = os.path.join(os.path.dirname(__file__), 'requests.json')
USERS_FILE = os.path.join(os.path.dirname(__file__), 'users.json')
WORKERS_FILE = os.path.join(os.path.dirname(__file__), 'workers.json')
PAYMENTS_FILE = os.path.join(os.path.dirname(__file__), 'payments.json')

# Helper functions for data management
def load_data(file_path):
    """Load data from JSON file"""
    if not os.path.exists(file_path):
        return []
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"Error loading {file_path}: {e}")
        return []

def save_data(file_path, data):
    """Save data to JSON file"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except IOError as e:
        print(f"Error saving {file_path}: {e}")
        return False

def load_requests():
    """Load requests from JSON file"""
    return load_data(DATA_FILE)

def save_requests(data):
    """Save requests to JSON file"""
    return save_data(DATA_FILE, data)

def load_users():
    """Load users from JSON file"""
    return load_data(USERS_FILE)

def save_users(data):
    """Save users to JSON file"""
    return save_data(USERS_FILE, data)

def load_workers():
    """Load workers from JSON file"""
    return load_data(WORKERS_FILE)

def save_workers(data):
    """Save workers to JSON file"""
    return save_data(WORKERS_FILE, data)

def load_payments():
    """Load payments from JSON file"""
    return load_data(PAYMENTS_FILE)

def save_payments(data):
    """Save payments to JSON file"""
    return save_data(PAYMENTS_FILE, data)

# Authentication helpers
def hash_password(password):
    """Hash a password"""
    return generate_password_hash(password)

def check_password(password_hash, password):
    """Check if password matches hash"""
    return check_password_hash(password_hash, password)

# TyreBot AI Agent
class TyreBot:
    def __init__(self):
        self.responses = {
            'greeting': [
                "Hello! I'm tyreBot, your tyre assistance helper. How can I assist you today?",
                "Hi there! I'm here to help with your tyre assistance needs. What can I do for you?",
                "Welcome! I'm tyreBot. Need help with a flat tyre or road assistance?",
            ],
            'pricing': [
                "Our basic tyre assistance service starts at R150. Additional services may vary. Would you like to request assistance?",
                "Standard tyre change service is R150. For premium services, prices range from R150 to R500 depending on the service needed.",
                "Pricing varies by service: Basic tyre change (R150), Emergency service (R200), Full tyre replacement (R300+).",
            ],
            'services': [
                "We offer: 1) Flat tyre assistance 2) Tyre replacement 3) Emergency road service 4) Tyre pressure check 5) Wheel alignment assistance",
                "Our services include flat tyre changes, emergency road assistance, tyre replacements, and vehicle towing if needed.",
                "We provide comprehensive tyre services: changing flat tyres, replacing tyres, emergency assistance, and more.",
            ],
            'payment': [
                "We accept online payments (card) and cash on delivery. Payment is required after service completion.",
                "You can pay online immediately or choose cash payment when the worker arrives. Both options are available.",
                "Payment options: 1) Online payment via card 2) Cash payment on site. Choose your preferred method when requesting service.",
            ],
            'location': [
                "Please provide your location by clicking on the map, or share your address. Our workers will navigate to you!",
                "You can select your location on the map when creating a request. Our GPS-enabled workers will find you quickly.",
                "Location is important! Use the map to pin your exact location for faster service delivery.",
            ],
            'default': [
                "I understand you need help. Could you provide more details about your tyre issue?",
                "I'm here to help! Can you tell me more about what you need assistance with?",
                "Let me help you with that. Please describe your situation in more detail.",
            ]
        }

    def respond(self, message):
        """Generate AI response based on user message"""
        message_lower = message.lower()
        
        # Greeting detection
        if any(word in message_lower for word in ['hello', 'hi', 'hey', 'greetings']):
            return secrets.choice(self.responses['greeting'])
        
        # Pricing queries
        if any(word in message_lower for word in ['price', 'cost', 'how much', 'payment', 'pay']):
            if 'payment' in message_lower or 'pay' in message_lower:
                return secrets.choice(self.responses['payment'])
            return secrets.choice(self.responses['pricing'])
        
        # Services queries
        if any(word in message_lower for word in ['service', 'what do you', 'help with', 'offer']):
            return secrets.choice(self.responses['services'])
        
        # Location queries
        if any(word in message_lower for word in ['location', 'where', 'find', 'come']):
            return secrets.choice(self.responses['location'])
        
        # Emergency
        if any(word in message_lower for word in ['emergency', 'urgent', 'asap', 'quick']):
            return "I understand this is urgent! Please create a request immediately and our nearest worker will be dispatched. Use the 'Request Assistance' button above."
        
        # Default response
        return secrets.choice(self.responses['default'])

tyre_bot = TyreBot()

# Payment Gateway (Simulated)
class PaymentGateway:
    def process_payment(self, amount, payment_method, card_details=None):
        """Process payment - simulated payment gateway"""
        payment_id = str(uuid.uuid4())
        
        if payment_method == 'cash':
            return {
                'success': True,
                'payment_id': payment_id,
                'method': 'cash',
                'status': 'pending',
                'message': 'Cash payment will be collected on delivery'
            }
        
        elif payment_method == 'online':
            # Simulate online payment processing
            # In production, integrate with real payment gateway (Stripe, PayPal, etc.)
            if card_details and self.validate_card(card_details):
                return {
                    'success': True,
                    'payment_id': payment_id,
                    'method': 'online',
                    'status': 'completed',
                    'amount': amount,
                    'message': 'Payment processed successfully'
                }
            else:
                return {
                    'success': False,
                    'payment_id': payment_id,
                    'message': 'Invalid card details'
                }
        
        return {
            'success': False,
            'message': 'Invalid payment method'
        }
    
    def validate_card(self, card_details):
        """Validate card details - simulated"""
        # Simple validation - in production, use proper validation
        card_number = card_details.get('card_number', '').replace(' ', '')
        if len(card_number) >= 13 and len(card_number) <= 19:
            if card_details.get('expiry_month') and card_details.get('expiry_year'):
                if card_details.get('cvv') and len(str(card_details.get('cvv'))) >= 3:
                    return True
        return False

payment_gateway = PaymentGateway()

# Routes
@app.route('/')
def index():
    """Main page"""
    user_id = session.get('user_id')
    user_type = session.get('user_type')
    user_name = session.get('user_name')
    reqs = load_requests()
    reqs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    return render_template('index.html', requests=reqs, user_id=user_id, user_type=user_type, user_name=user_name)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """User sign up"""
    if request.method == 'POST':
        data = request.get_json() if request.is_json else request.form
        user_type = data.get('user_type', 'user')  # 'user' or 'worker'
        email = data.get('email', '').strip().lower()
        password = data.get('password', '').strip()
        name = data.get('name', '').strip()
        phone = data.get('phone', '').strip()
        
        if not all([email, password, name, phone]):
            return jsonify({'success': False, 'error': 'All fields are required'}), 400
        
        if user_type == 'worker':
            workers = load_workers()
            if any(w.get('email') == email for w in workers):
                return jsonify({'success': False, 'error': 'Email already registered'}), 400
            
            worker = {
                'id': str(uuid.uuid4()),
                'email': email,
                'password': hash_password(password),
                'name': name,
                'phone': phone,
                'created_at': datetime.now().isoformat(),
                'type': 'worker'
            }
            workers.append(worker)
            if save_workers(workers):
                session['user_id'] = worker['id']
                session['user_type'] = 'worker'
                session['user_name'] = worker['name']
                if request.is_json:
                    return jsonify({'success': True, 'user': {'id': worker['id'], 'name': worker['name'], 'type': 'worker'}}), 201
                return redirect(url_for('worker_dashboard'))
        else:
            users = load_users()
            if any(u.get('email') == email for u in users):
                return jsonify({'success': False, 'error': 'Email already registered'}), 400
            
            user = {
                'id': str(uuid.uuid4()),
                'email': email,
                'password': hash_password(password),
                'name': name,
                'phone': phone,
                'created_at': datetime.now().isoformat(),
                'type': 'user'
            }
            users.append(user)
            if save_users(users):
                session['user_id'] = user['id']
                session['user_type'] = 'user'
                session['user_name'] = user['name']
                if request.is_json:
                    return jsonify({'success': True, 'user': {'id': user['id'], 'name': user['name'], 'type': 'user'}}), 201
                return redirect(url_for('index'))
        
        return jsonify({'success': False, 'error': 'Failed to create account'}), 500
    
    return render_template('auth.html', mode='signup')

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    """User sign in"""
    if request.method == 'POST':
        data = request.get_json() if request.is_json else request.form
        user_type = data.get('user_type', 'user')
        email = data.get('email', '').strip().lower()
        password = data.get('password', '').strip()
        
        if not all([email, password]):
            return jsonify({'success': False, 'error': 'Email and password are required'}), 400
        
        if user_type == 'worker':
            workers = load_workers()
            worker = next((w for w in workers if w.get('email') == email), None)
            if worker and check_password(worker.get('password'), password):
                session['user_id'] = worker['id']
                session['user_type'] = 'worker'
                session['user_name'] = worker['name']
                if request.is_json:
                    return jsonify({'success': True, 'user': {'id': worker['id'], 'name': worker['name'], 'type': 'worker'}})
                return redirect(url_for('worker_dashboard'))
        else:
            users = load_users()
            user = next((u for u in users if u.get('email') == email), None)
            if user and check_password(user.get('password'), password):
                session['user_id'] = user['id']
                session['user_type'] = 'user'
                session['user_name'] = user['name']
                if request.is_json:
                    return jsonify({'success': True, 'user': {'id': user['id'], 'name': user['name'], 'type': 'user'}})
                return redirect(url_for('index'))
        
        return jsonify({'success': False, 'error': 'Invalid email or password'}), 401
    
    return render_template('auth.html', mode='signin')

@app.route('/signout')
def signout():
    """Sign out"""
    session.clear()
    return redirect(url_for('index'))

@app.route('/request', methods=['POST'])
def request_assist():
    """Handle assistance request submission"""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Please sign in to request assistance'}), 401
    
    if request.is_json:
        data = request.get_json()
    else:
        data = {
            'name': request.form.get('name', '').strip(),
            'phone': request.form.get('phone', '').strip(),
            'location': request.form.get('location', '').strip(),
            'vehicle': request.form.get('vehicle', '').strip(),
            'tyre_size': request.form.get('tyre_size', '').strip(),
            'notes': request.form.get('notes', '').strip(),
            'payment_method': request.form.get('payment_method', 'cash').strip(),
            'amount': float(request.form.get('amount', 150))
        }
    
    errors = validate_request_data(data)
    if errors:
        if request.is_json:
            return jsonify({'success': False, 'errors': errors}), 400
        return redirect(url_for('index'))
    
    # Process payment
    payment_method = data.get('payment_method', 'cash')
    amount = data.get('amount', 150.0)
    card_details = data.get('card_details')
    
    payment_result = payment_gateway.process_payment(amount, payment_method, card_details)
    
    if not payment_result.get('success') and payment_method == 'online':
        return jsonify({'success': False, 'error': 'Payment failed: ' + payment_result.get('message')}), 400
    
    # Save payment record
    payments = load_payments()
    payment_record = {
        'id': payment_result.get('payment_id'),
        'user_id': user_id,
        'amount': amount,
        'method': payment_method,
        'status': payment_result.get('status'),
        'timestamp': datetime.now().isoformat()
    }
    payments.append(payment_record)
    save_payments(payments)
    
    # Create request entry
    entry = {
        'id': str(uuid.uuid4()),
        'user_id': user_id,
        'name': data['name'],
        'phone': data['phone'],
        'location': data['location'],
        'vehicle': data.get('vehicle', ''),
        'tyre_size': data.get('tyre_size', ''),
        'notes': data.get('notes', ''),
        'timestamp': datetime.now().isoformat(),
        'status': 'pending',
        'payment_id': payment_record['id'],
        'payment_method': payment_method,
        'amount': amount
    }
    
    requests_data = load_requests()
    requests_data.append(entry)
    
    if not save_requests(requests_data):
        return jsonify({'success': False, 'error': 'Failed to save request'}), 500
    
    if request.is_json:
        return jsonify({'success': True, 'request': entry, 'payment': payment_result}), 201
    return redirect(url_for('index'))

def validate_request_data(data):
    """Validate request data"""
    errors = []
    if not data.get('name') or not data['name'].strip():
        errors.append('Name is required')
    if not data.get('phone') or not data['phone'].strip():
        errors.append('Phone number is required')
    
    location = data.get('location', '').strip()
    if not location:
        errors.append('Location is required')
    else:
        if ',' not in location:
            errors.append('Location must be in format: latitude,longitude')
        else:
            try:
                parts = location.split(',')
                if len(parts) != 2:
                    errors.append('Location must be in format: latitude,longitude')
                else:
                    lat = float(parts[0].strip())
                    lng = float(parts[1].strip())
                    if not (-90 <= lat <= 90):
                        errors.append('Latitude must be between -90 and 90')
                    if not (-180 <= lng <= 180):
                        errors.append('Longitude must be between -180 and 180')
            except ValueError:
                errors.append('Location coordinates must be valid numbers')
    return errors

@app.route('/api/tyrebot', methods=['POST'])
def tyrebot_api():
    """TyreBot AI agent API"""
    data = request.get_json()
    message = data.get('message', '').strip()
    
    if not message:
        return jsonify({'success': False, 'error': 'Message is required'}), 400
    
    response = tyre_bot.respond(message)
    return jsonify({'success': True, 'response': response, 'bot': 'tyreBot'})

@app.route('/api/requests', methods=['GET'])
def api_requests():
    """API endpoint to get all requests"""
    reqs = load_requests()
    reqs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    return jsonify(reqs)

@app.route('/api/requests/<request_id>', methods=['GET'])
def api_request_by_id(request_id):
    """API endpoint to get a specific request by ID"""
    reqs = load_requests()
    req = next((r for r in reqs if r.get('id') == request_id), None)
    if not req:
        return jsonify({'error': 'Request not found'}), 404
    return jsonify(req)

@app.route('/api/requests/<request_id>/status', methods=['PUT', 'PATCH'])
def api_update_request_status(request_id):
    """API endpoint to update request status"""
    reqs = load_requests()
    req = next((r for r in reqs if r.get('id') == request_id), None)
    
    if not req:
        return jsonify({'error': 'Request not found'}), 404
    
    data = request.get_json() if request.is_json else request.form
    new_status = data.get('status', '').strip().lower()
    worker_id = session.get('user_id') or data.get('worker_id', '').strip()
    
    valid_statuses = ['pending', 'assigned', 'in-progress', 'completed', 'cancelled']
    if new_status not in valid_statuses:
        return jsonify({'error': f'Invalid status. Must be one of: {", ".join(valid_statuses)}'}), 400
    
    req['status'] = new_status
    if worker_id:
        req['worker_id'] = worker_id
    if new_status in ['assigned', 'in-progress']:
        req['assigned_at'] = datetime.now().isoformat()
    if new_status == 'completed':
        req['completed_at'] = datetime.now().isoformat()
        # Process payment if cash
        if req.get('payment_method') == 'cash' and req.get('payment_status') != 'completed':
            payments = load_payments()
            payment = next((p for p in payments if p.get('id') == req.get('payment_id')), None)
            if payment:
                payment['status'] = 'completed'
                payment['completed_at'] = datetime.now().isoformat()
                save_payments(payments)
                req['payment_status'] = 'completed'
    
    if save_requests(reqs):
        return jsonify({'success': True, 'request': req}), 200
    return jsonify({'error': 'Failed to update request'}), 500

@app.route('/api/requests/pending', methods=['GET'])
def api_pending_requests():
    """API endpoint to get all pending requests for workers"""
    reqs = load_requests()
    pending = [r for r in reqs if r.get('status') == 'pending']
    pending.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    return jsonify(pending)

def calculate_route_data(start_lat, start_lng, end_lat, end_lng):
    """Calculate route data between two points"""
    def haversine_distance(lat1, lon1, lat2, lon2):
        R = 6371
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        return R * c
    
    distance_km = haversine_distance(start_lat, start_lng, end_lat, end_lng)
    
    return {
        'distance': round(distance_km, 2),
        'distance_km': round(distance_km, 2),
        'distance_miles': round(distance_km * 0.621371, 2),
        'duration_seconds': int(distance_km * 120),
        'duration_minutes': round(distance_km * 2, 1),
        'waypoints': [
            {'lat': start_lat, 'lng': start_lng},
            {'lat': end_lat, 'lng': end_lng}
        ],
        'geometry': [
            [start_lng, start_lat],
            [end_lng, end_lat]
        ],
        'instructions': [
            f'Start at {start_lat:.5f}, {start_lng:.5f}',
            f'Navigate to destination: {end_lat:.5f}, {end_lng:.5f}',
            f'Estimated distance: {distance_km:.2f} km',
            f'Estimated time: {round(distance_km * 2, 1)} minutes'
        ]
    }

@app.route('/api/navigation/route', methods=['GET'])
def api_get_route():
    """API endpoint to get navigation route between two points"""
    start_lat = request.args.get('start_lat', type=float)
    start_lng = request.args.get('start_lng', type=float)
    end_lat = request.args.get('end_lat', type=float)
    end_lng = request.args.get('end_lng', type=float)
    
    if not all([start_lat, start_lng, end_lat, end_lng]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    if not (-90 <= start_lat <= 90) or not (-90 <= end_lat <= 90):
        return jsonify({'error': 'Invalid latitude values'}), 400
    if not (-180 <= start_lng <= 180) or not (-180 <= end_lng <= 180):
        return jsonify({'error': 'Invalid longitude values'}), 400
    
    try:
        route = calculate_route_data(start_lat, start_lng, end_lat, end_lng)
        return jsonify(route)
    except Exception as e:
        return jsonify({'error': f'Failed to calculate route: {str(e)}'}), 500

@app.route('/worker')
def worker_dashboard():
    """Worker dashboard page"""
    if not session.get('user_id') or session.get('user_type') != 'worker':
        return redirect(url_for('signin') + '?type=worker')
    
    reqs = load_requests()
    pending = [r for r in reqs if r.get('status') == 'pending']
    assigned = [r for r in reqs if r.get('status') in ['assigned', 'in-progress'] and r.get('worker_id') == session.get('user_id')]
    return render_template('worker.html', pending_requests=pending, assigned_requests=assigned, user_name=session.get('user_name'))

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() in ('1', 'true', 'yes')
    app.run(host='0.0.0.0', port=5000, debug=debug)
