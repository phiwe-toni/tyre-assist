(() => {
  const toggle = document.getElementById('tyreBotToggle');
  const chat = document.getElementById('tyreBotChat');
  const close = document.getElementById('tyreBotClose');
  const input = document.getElementById('tyreBotInput');
  const sendBtn = document.getElementById('tyreBotSend');
  const messagesContainer = document.getElementById('tyreBotMessages');

  if (!toggle || !chat) return;

  let isOpen = false;

  function toggleChat() {
    isOpen = !isOpen;
    chat.style.display = isOpen ? 'flex' : 'none';
  }

  function addMessage(text, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `tyrebot-message ${isUser ? 'user' : 'bot'}`;
    messageDiv.innerHTML = `<p>${escapeHtml(text)}</p>`;
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  async function sendMessage() {
    const message = input.value.trim();
    if (!message) return;

    addMessage(message, true);
    input.value = '';
    input.disabled = true;
    sendBtn.disabled = true;

    try {
      const response = await fetch('/api/tyrebot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message })
      });

      const data = await response.json();
      if (data.success) {
        setTimeout(() => {
          addMessage(data.response, false);
          input.disabled = false;
          sendBtn.disabled = false;
          input.focus();
        }, 500);
      } else {
        addMessage('Sorry, I encountered an error. Please try again.', false);
        input.disabled = false;
        sendBtn.disabled = false;
      }
    } catch (error) {
      console.error('Error:', error);
      addMessage('Sorry, I\'m having trouble connecting. Please try again later.', false);
      input.disabled = false;
      sendBtn.disabled = false;
    }
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  toggle.addEventListener('click', toggleChat);
  close.addEventListener('click', toggleChat);
  sendBtn.addEventListener('click', sendMessage);
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });

  // Auto-open on first visit (after 3 seconds)
  setTimeout(() => {
    if (!localStorage.getItem('tyreBotSeen')) {
      toggleChat();
      localStorage.setItem('tyreBotSeen', 'true');
    }
  }, 3000);
})();

