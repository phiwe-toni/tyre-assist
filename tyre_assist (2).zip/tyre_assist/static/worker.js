(() => {
  const DEFAULT_CENTER = [-29.85, 31.02];
  const DEFAULT_ZOOM = 11;
  
  let navigationMap;
  let routeLayer;
  let currentRoute = null;
  let workerLocation = { lat: DEFAULT_CENTER[0], lng: DEFAULT_CENTER[1] };
  let requestMarkers = [];
  let workerMarker = null;

  // Initialize map
  function initMap() {
    const mapEl = document.getElementById('navigationMap');
    if (!mapEl) return;

    navigationMap = L.map(mapEl).setView(DEFAULT_CENTER, DEFAULT_ZOOM);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(navigationMap);

    // Add worker location marker
    updateWorkerMarker();
  }

  function updateWorkerMarker() {
    if (!navigationMap) return;
    
    if (workerMarker) {
      navigationMap.removeLayer(workerMarker);
    }
    
    workerMarker = L.marker([workerLocation.lat, workerLocation.lng], {
      icon: L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
      })
    }).addTo(navigationMap);
    
    workerMarker.bindPopup('<b>Your Location (Worker)</b>');
  }

  function parseLocation(locationString) {
    if (!locationString) return null;
    const parts = String(locationString).split(',').map(v => v.trim());
    if (parts.length !== 2) return null;
    const lat = parseFloat(parts[0]);
    const lng = parseFloat(parts[1]);
    if (isNaN(lat) || isNaN(lng)) return null;
    return { lat, lng };
  }

  async function getRoute(startLat, startLng, endLat, endLng) {
    try {
      const response = await fetch(`/api/navigation/route?start_lat=${startLat}&start_lng=${startLng}&end_lat=${endLat}&end_lng=${endLng}`);
      if (!response.ok) {
        throw new Error('Failed to get route');
      }
      return await response.json();
    } catch (error) {
      console.error('Error getting route:', error);
      showMessage('Failed to calculate route', 'error');
      return null;
    }
  }

  function showRoute(routeData) {
    if (!navigationMap || !routeData) return;

    // Clear existing route
    clearRoute();

    // Draw route line
    const routeCoordinates = routeData.geometry.map(coord => [coord[1], coord[0]]);
    routeLayer = L.polyline(routeCoordinates, {
      color: '#d32f2f',
      weight: 5,
      opacity: 0.7
    }).addTo(navigationMap);

    // Add start marker
    const start = routeData.waypoints[0];
    L.marker([start.lat, start.lng], {
      icon: L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41]
      })
    }).addTo(navigationMap).bindPopup('<b>Start (Your Location)</b>');

    // Add end marker
    const end = routeData.waypoints[1];
    L.marker([end.lat, end.lng], {
      icon: L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41]
      })
    }).addTo(navigationMap).bindPopup('<b>Destination (Customer)</b>');

    // Fit map to show entire route
    navigationMap.fitBounds(routeCoordinates, { padding: [50, 50] });

    // Update route info
    updateRouteInfo(routeData);

    currentRoute = routeData;
  }

  function clearRoute() {
    if (routeLayer) {
      navigationMap.removeLayer(routeLayer);
      routeLayer = null;
    }
    currentRoute = null;
    updateRouteInfo(null);
  }

  function updateRouteInfo(routeData) {
    const routeInfo = document.getElementById('routeInfo');
    const distanceEl = document.getElementById('routeDistance');
    const durationEl = document.getElementById('routeDuration');

    if (!routeData) {
      routeInfo.style.display = 'none';
      return;
    }

    routeInfo.style.display = 'block';
    distanceEl.textContent = `Distance: ${routeData.distance_km} km`;
    durationEl.textContent = `Est. Time: ${routeData.duration_minutes} min`;
  }

  async function navigateToLocation(locationString, requestId) {
    const location = parseLocation(locationString);
    if (!location) {
      showMessage('Invalid location', 'error');
      return;
    }

    // Update worker location from inputs
    const workerLatInput = document.getElementById('workerLat');
    const workerLngInput = document.getElementById('workerLng');
    
    if (workerLatInput && workerLngInput) {
      const lat = parseFloat(workerLatInput.value);
      const lng = parseFloat(workerLngInput.value);
      if (!isNaN(lat) && !isNaN(lng)) {
        workerLocation = { lat, lng };
        updateWorkerMarker();
      }
    }

    // Get route
    const routeData = await getRoute(workerLocation.lat, workerLocation.lng, location.lat, location.lng);
    if (routeData) {
      showRoute(routeData);
      showMessage(`Route calculated: ${routeData.distance_km} km, ${routeData.duration_minutes} min`, 'success');
    }
  }

  async function updateRequestStatus(requestId, status, workerId = 'worker-1') {
    try {
      const response = await fetch(`/api/requests/${requestId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status, worker_id: workerId })
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to update status');
      }

      const data = await response.json();
      showMessage(`Request status updated to ${status}`, 'success');
      refreshRequests();
      return data;
    } catch (error) {
      console.error('Error updating status:', error);
      showMessage(error.message || 'Failed to update request status', 'error');
      return null;
    }
  }

  async function refreshRequests() {
    try {
      const response = await fetch('/api/requests/pending');
      if (!response.ok) throw new Error('Failed to fetch requests');
      
      const pending = await response.json();
      renderPendingRequests(pending);

      // Also refresh assigned requests
      const allResponse = await fetch('/api/requests');
      if (allResponse.ok) {
        const all = await allResponse.json();
        const assigned = all.filter(r => r.status === 'assigned' || r.status === 'in-progress');
        renderAssignedRequests(assigned);
      }
    } catch (error) {
      console.error('Error refreshing requests:', error);
      showMessage('Failed to refresh requests', 'error');
    }
  }

  function renderPendingRequests(requests) {
    const container = document.getElementById('pendingRequests');
    if (!container) return;

    if (requests.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <h3>No pending requests</h3>
          <p>All assistance requests have been handled.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = requests.map(req => {
      const location = parseLocation(req.location);
      const timestamp = req.timestamp ? new Date(req.timestamp).toLocaleString() : '';
      
      return `
        <div class="request-card" data-request-id="${req.id}">
          <div class="request-header">
            <h3>${escapeHtml(req.name || 'Unknown')}</h3>
            <span class="status-badge status-pending">Pending</span>
          </div>
          <div class="request-info">
                <p><strong>Phone:</strong> ${escapeHtml(req.phone || '')}</p>
                ${req.vehicle ? `<p><strong>Vehicle:</strong> ${escapeHtml(req.vehicle)}</p>` : ''}
                ${req.tyre_size ? `<p><strong>Tyre Size:</strong> ${escapeHtml(req.tyre_size)}</p>` : ''}
                ${req.notes ? `<p><strong>Notes:</strong> ${escapeHtml(req.notes)}</p>` : ''}
                <p><strong>Location:</strong> ${escapeHtml(req.location || '')}</p>
                ${req.amount ? `<p><strong>Amount:</strong> R${req.amount}</p>` : ''}
                ${req.payment_method ? `<p><strong>Payment:</strong> ${escapeHtml(req.payment_method)}</p>` : ''}
                <p><small>Requested: ${escapeHtml(timestamp)}</small></p>
          </div>
          <div class="request-actions">
            <button class="btn-primary btn-navigate" data-location="${escapeHtml(req.location || '')}" data-request-id="${req.id}">Navigate</button>
            <button class="btn-secondary btn-assign" data-request-id="${req.id}">Accept</button>
          </div>
        </div>
      `;
    }).join('');

    // Re-attach event listeners
    attachRequestListeners();
  }

  function renderAssignedRequests(requests) {
    const container = document.getElementById('assignedRequests');
    if (!container) return;

    if (requests.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <h3>No assigned jobs</h3>
          <p>Accept a request to see it here.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = requests.map(req => {
      const location = parseLocation(req.location);
      const assignedAt = req.assigned_at ? new Date(req.assigned_at).toLocaleString() : (req.timestamp ? new Date(req.timestamp).toLocaleString() : '');
      
      return `
        <div class="request-card" data-request-id="${req.id}">
          <div class="request-header">
            <h3>${escapeHtml(req.name || 'Unknown')}</h3>
            <span class="status-badge status-${req.status || 'assigned'}">${(req.status || 'assigned').replace('-', ' ')}</span>
          </div>
          <div class="request-info">
            <p><strong>Phone:</strong> ${escapeHtml(req.phone || '')}</p>
            <p><strong>Location:</strong> ${escapeHtml(req.location || '')}</p>
            <p><small>Assigned: ${escapeHtml(assignedAt)}</small></p>
          </div>
          <div class="request-actions">
            <button class="btn-primary btn-navigate" data-location="${escapeHtml(req.location || '')}" data-request-id="${req.id}">Navigate</button>
            ${req.status !== 'in-progress' ? `<button class="btn-status btn-in-progress" data-request-id="${req.id}" data-status="in-progress">Start</button>` : ''}
            <button class="btn-status btn-complete" data-request-id="${req.id}" data-status="completed">Complete</button>
          </div>
        </div>
      `;
    }).join('');

    // Re-attach event listeners
    attachRequestListeners();
  }

  function attachRequestListeners() {
    // Navigate buttons
    document.querySelectorAll('.btn-navigate').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const location = e.target.getAttribute('data-location');
        const requestId = e.target.getAttribute('data-request-id');
        await navigateToLocation(location, requestId);
      });
    });

    // Accept/Assign buttons
    document.querySelectorAll('.btn-assign').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const requestId = e.target.getAttribute('data-request-id');
        await updateRequestStatus(requestId, 'assigned');
      });
    });

    // Status update buttons
    document.querySelectorAll('.btn-status[data-status]').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const requestId = e.target.getAttribute('data-request-id');
        const status = e.target.getAttribute('data-status');
        await updateRequestStatus(requestId, status);
      });
    });
  }

  function getCurrentLocation() {
    if (!navigator.geolocation) {
      showMessage('Geolocation is not supported by your browser', 'error');
      return;
    }

    showMessage('Getting your location...', 'success');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        workerLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        
        const workerLatInput = document.getElementById('workerLat');
        const workerLngInput = document.getElementById('workerLng');
        
        if (workerLatInput) workerLatInput.value = workerLocation.lat.toFixed(5);
        if (workerLngInput) workerLngInput.value = workerLocation.lng.toFixed(5);
        
        updateWorkerMarker();
        if (navigationMap) {
          navigationMap.setView([workerLocation.lat, workerLocation.lng], 13);
        }
        showMessage('Location updated!', 'success');
      },
      (error) => {
        console.error('Geolocation error:', error);
        showMessage('Failed to get your location', 'error');
      }
    );
  }

  function showMessage(message, type = 'success') {
    const existing = document.querySelector('.message-toast');
    if (existing) existing.remove();

    const messageEl = document.createElement('div');
    messageEl.className = `message-toast message-${type}`;
    messageEl.textContent = message;
    document.body.appendChild(messageEl);

    setTimeout(() => {
      messageEl.classList.add('show');
    }, 10);

    setTimeout(() => {
      messageEl.classList.remove('show');
      setTimeout(() => messageEl.remove(), 300);
    }, 4000);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Initialize
  document.addEventListener('DOMContentLoaded', () => {
    initMap();
    attachRequestListeners();

    // Refresh button
    const refreshBtn = document.getElementById('refreshRequests');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', refreshRequests);
    }

    // Clear route button
    const clearBtn = document.getElementById('clearRoute');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        clearRoute();
        showMessage('Route cleared', 'success');
      });
    }

    // Geolocate button
    const geolocateBtn = document.getElementById('getCurrentLocation');
    if (geolocateBtn) {
      geolocateBtn.addEventListener('click', getCurrentLocation);
    }

    // Update worker location from inputs
    const workerLatInput = document.getElementById('workerLat');
    const workerLngInput = document.getElementById('workerLng');
    
    if (workerLatInput && workerLngInput) {
      workerLatInput.addEventListener('change', () => {
        const lat = parseFloat(workerLatInput.value);
        if (!isNaN(lat)) {
          workerLocation.lat = lat;
          updateWorkerMarker();
        }
      });
      
      workerLngInput.addEventListener('change', () => {
        const lng = parseFloat(workerLngInput.value);
        if (!isNaN(lng)) {
          workerLocation.lng = lng;
          updateWorkerMarker();
        }
      });
    }

    // Auto-refresh every 30 seconds
    setInterval(refreshRequests, 30000);
  });
})();

