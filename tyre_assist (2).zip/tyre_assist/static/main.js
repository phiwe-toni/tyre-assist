(() => {
  const DEFAULT_CENTER = [-29.85, 31.02];
  const DEFAULT_ZOOM = 11;
  let REQUESTS = Array.isArray(window.__REQUESTS__) ? window.__REQUESTS__ : [];

  const coordDisplay = document.getElementById('coordDisplay');
  const locationInput = document.getElementById('location');
  const locationPickerEl = document.getElementById('locationPicker');
  const requestsMapEl = document.getElementById('requestsMap');
  const heroMapEl = document.getElementById('heroMap');
  const assistForm = document.getElementById('assistForm');
  const requestsContainer = document.getElementById('requests');
  
  let pickerMap, requestsMap, pickerMarker, requestMarkers = [], poiMarkers = [];

  const POIS = [
    { lat: -29.8395, lng: 31.0227, type: 'Tyre Shop', name: 'Durban Tyres' },
    { lat: -29.8586, lng: 31.0218, type: 'Tyre Shop', name: 'KZN Tyre Centre' },
    { lat: -29.8485, lng: 31.0343, type: 'Fuel Station', name: 'Total Garage' },
    { lat: -29.8563, lng: 31.0342, type: 'Fuel Station', name: 'Shell Ultra City' }
  ];

  function createBaseMap(element, options = {}) {
    if (!element) return null;
    const map = L.map(element, {
      attributionControl: true,
      scrollWheelZoom: options.scrollWheelZoom ?? true,
      dragging: options.dragging ?? true,
      zoomControl: options.zoomControl ?? true,
      doubleClickZoom: options.doubleClickZoom ?? true,
      boxZoom: options.boxZoom ?? true,
      keyboard: options.keyboard ?? true
    }).setView(options.center || DEFAULT_CENTER, options.zoom || DEFAULT_ZOOM);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      tileSize: 256,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    return map;
  }

  function setCoordinateDisplay(latlng) {
    if (!coordDisplay) return;
    if (!latlng) {
      coordDisplay.textContent = 'No location selected';
      coordDisplay.classList.remove('is-active');
      return;
    }
    coordDisplay.innerHTML = `Pin dropped at <b>${latlng.lat.toFixed(5)}, ${latlng.lng.toFixed(5)}</b>`;
    coordDisplay.classList.add('is-active');
  }

  function parseRequestCoordinates(request) {
    if (!request || !request.location) return null;
    const parts = String(request.location).split(',').map(v => v.trim());
    if (parts.length !== 2) return null;
    const lat = Number(parts[0]);
    const lng = Number(parts[1]);
    if (Number.isNaN(lat) || Number.isNaN(lng)) return null;
    return { lat, lng };
  }

  // Hero card decorative map
  const heroMap = createBaseMap(heroMapEl, {
    center: DEFAULT_CENTER,
    zoom: 10,
    scrollWheelZoom: false,
    dragging: false,
    zoomControl: false,
    doubleClickZoom: false,
    boxZoom: false,
    keyboard: false
  });

  if (heroMap) {
    L.circleMarker(DEFAULT_CENTER, {
      radius: 14,
      color: '#d32f2f',
      fillColor: '#d32f2f',
      fillOpacity: 0.85,
      weight: 3
    }).addTo(heroMap);
  }

  // Interactive picker map
  pickerMap = createBaseMap(locationPickerEl, {
    center: DEFAULT_CENTER,
    zoom: DEFAULT_ZOOM
  });

  if (pickerMap && locationInput) {
    function updateMarker(latlng) {
      if (!latlng) return;
      if (pickerMarker) pickerMap.removeLayer(pickerMarker);
      pickerMarker = L.marker(latlng, { draggable: false }).addTo(pickerMap);
      if (locationInput) {
        locationInput.value = `${latlng.lat},${latlng.lng}`;
      }
      setCoordinateDisplay(latlng);
    }

    pickerMap.on('click', event => {
      updateMarker(event.latlng);
    });

    if (locationInput.value) {
      const existing = parseRequestCoordinates({ location: locationInput.value });
      if (existing) {
        pickerMap.setView(existing, 14);
        updateMarker(existing);
      }
    } else {
      setCoordinateDisplay(null);
    }
  }

  // Map showing all requests and POIs
  requestsMap = createBaseMap(requestsMapEl, {
    center: DEFAULT_CENTER,
    zoom: 9
  });

  function updateRequestsMap() {
    if (!requestsMap) return;
    
    // Clear existing request markers
    requestMarkers.forEach(marker => requestsMap.removeLayer(marker));
    requestMarkers = [];
    
    const bounds = [];

    // Add request markers
    REQUESTS.forEach(request => {
      const coords = parseRequestCoordinates(request);
      if (!coords) return;
      
      const timestamp = request.timestamp ? new Date(request.timestamp).toLocaleString() : '';
      const popup = [
        `<b>${request.name ?? 'Unknown contact'}</b>`,
        request.phone ? `<span class="popup-meta">${request.phone}</span>` : '',
        [request.vehicle, request.tyre_size].filter(Boolean).join(' &bull; '),
        request.notes ? `<span class="popup-notes">${request.notes}</span>` : '',
        timestamp ? `<small style="color: #666;">${timestamp}</small>` : ''
      ].filter(Boolean).join('<br>');

      const marker = L.marker([coords.lat, coords.lng]).addTo(requestsMap);
      marker.bindPopup(popup, {
        closeButton: true,
        autoClose: false
      });
      requestMarkers.push(marker);
      bounds.push([coords.lat, coords.lng]);
    });

    // Add POIs only if they haven't been added yet
    if (poiMarkers.length === 0) {
      POIS.forEach(poi => {
        const marker = L.circleMarker([poi.lat, poi.lng], {
          radius: 8,
          color: poi.type.includes('Fuel') ? '#1976d2' : '#2e7d32',
          fillColor: poi.type.includes('Fuel') ? '#1976d2' : '#2e7d32',
          fillOpacity: 0.9,
          weight: 2
        }).addTo(requestsMap);

        marker.bindPopup(`<b>${poi.name}</b><br>${poi.type}`);
        poiMarkers.push(marker);
        bounds.push([poi.lat, poi.lng]);
      });
    } else {
      // Add POI coordinates to bounds for fitting
      POIS.forEach(poi => {
        bounds.push([poi.lat, poi.lng]);
      });
    }

    // Fit bounds or set view
    if (bounds.length > 1) {
      requestsMap.fitBounds(bounds, { padding: [24, 24], maxZoom: 14 });
    } else if (bounds.length === 1) {
      requestsMap.setView(bounds[0], DEFAULT_ZOOM);
    }
  }

  // Initialize requests map
  updateRequestsMap();

  // Form submission handling
  function showMessage(message, type = 'success') {
    // Remove existing messages
    const existing = document.querySelector('.message-toast');
    if (existing) existing.remove();

    const messageEl = document.createElement('div');
    messageEl.className = `message-toast message-${type}`;
    messageEl.textContent = message;
    document.body.appendChild(messageEl);

    setTimeout(() => {
      messageEl.classList.add('show');
    }, 10);

    setTimeout(() => {
      messageEl.classList.remove('show');
      setTimeout(() => messageEl.remove(), 300);
    }, 4000);
  }

  function formatTimestamp(timestamp) {
    if (!timestamp) return '';
    try {
      const date = new Date(timestamp);
      return date.toLocaleString();
    } catch {
      return timestamp;
    }
  }

  function renderRequestsList() {
    if (!requestsContainer) return;

    if (REQUESTS.length === 0) {
      requestsContainer.innerHTML = `
        <div class="empty-state">
          <h3>No requests yet</h3>
          <p>Your upcoming tyre assistance jobs will appear here.</p>
        </div>
      `;
      return;
    }

    const ul = document.createElement('ul');
    REQUESTS.forEach(request => {
      const li = document.createElement('li');
      li.className = 'request-item';
      
      const timestamp = formatTimestamp(request.timestamp);
      li.innerHTML = `
        <div class="request-meta">
          <strong>${escapeHtml(request.name || 'Unknown')}</strong>
          <span class="phone">${escapeHtml(request.phone || '')}</span>
        </div>
        ${request.location ? `<span class="location-tag">${escapeHtml(request.location)}</span>` : ''}
        <div class="request-details">
          ${request.vehicle ? `<span>${escapeHtml(request.vehicle)}</span>` : ''}
          ${request.tyre_size ? `<span>${escapeHtml(request.tyre_size)}</span>` : ''}
        </div>
        ${request.notes ? `<p class="notes">${escapeHtml(request.notes)}</p>` : ''}
        ${timestamp ? `<small class="timestamp">${escapeHtml(timestamp)}</small>` : ''}
      `;
      ul.appendChild(li);
    });

    requestsContainer.innerHTML = '';
    requestsContainer.appendChild(ul);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function validateForm() {
    const name = assistForm.querySelector('[name="name"]').value.trim();
    const phone = assistForm.querySelector('[name="phone"]').value.trim();
    const location = locationInput.value.trim();

    if (!name) {
      showMessage('Please enter your name', 'error');
      assistForm.querySelector('[name="name"]').focus();
      return false;
    }

    if (!phone) {
      showMessage('Please enter your phone number', 'error');
      assistForm.querySelector('[name="phone"]').focus();
      return false;
    }

    if (!location) {
      showMessage('Please select a location on the map', 'error');
      if (pickerMap) {
        pickerMap.setView(DEFAULT_CENTER, DEFAULT_ZOOM);
      }
      return false;
    }

    // Validate location format
    const parts = location.split(',');
    if (parts.length !== 2) {
      showMessage('Invalid location format. Please click on the map again.', 'error');
      return false;
    }

    try {
      const lat = parseFloat(parts[0].trim());
      const lng = parseFloat(parts[1].trim());
      if (isNaN(lat) || isNaN(lng)) {
        showMessage('Invalid coordinates. Please select a location on the map.', 'error');
        return false;
      }
    } catch {
      showMessage('Invalid location format. Please select a location on the map.', 'error');
      return false;
    }

    return true;
  }

  async function submitForm(event) {
    event.preventDefault();

    if (!validateForm()) {
      return;
    }

    // Validate payment method if online
    const paymentMethod = assistForm.querySelector('input[name="payment_method"]:checked')?.value;
    if (paymentMethod === 'online') {
      const cardNumber = assistForm.querySelector('input[name="card_number"]')?.value.replace(/\s/g, '');
      const expiry = assistForm.querySelector('input[name="expiry"]')?.value;
      const cvv = assistForm.querySelector('input[name="cvv"]')?.value;

      if (!cardNumber || cardNumber.length < 13) {
        showMessage('Please enter a valid card number', 'error');
        return;
      }

      if (!expiry || !expiry.match(/^\d{2}\/\d{2}$/)) {
        showMessage('Please enter a valid expiry date (MM/YY)', 'error');
        return;
      }

      if (!cvv || cvv.length < 3) {
        showMessage('Please enter a valid CVV', 'error');
        return;
      }
    }

    const formData = new FormData(assistForm);
    const data = Object.fromEntries(formData);
    data.amount = parseFloat(data.amount || 150);

    // Add card details for online payment
    if (paymentMethod === 'online') {
      const cardNumber = assistForm.querySelector('input[name="card_number"]').value.replace(/\s/g, '');
      const expiry = assistForm.querySelector('input[name="expiry"]').value;
      const cvv = assistForm.querySelector('input[name="cvv"]').value;
      const [month, year] = expiry.split('/');
      
      data.card_details = {
        card_number: cardNumber,
        expiry_month: parseInt(month),
        expiry_year: 2000 + parseInt(year),
        cvv: cvv
      };
    }

    const submitButton = assistForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = paymentMethod === 'online' ? 'Processing Payment...' : 'Submitting...';

    try {
      const response = await fetch('/request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (response.ok && result.success) {
        // Fetch updated requests
        const requestsResponse = await fetch('/api/requests');
        if (requestsResponse.ok) {
          REQUESTS = await requestsResponse.json();
          renderRequestsList();
          updateRequestsMap();
        }

        const paymentMsg = result.payment ? ` ${result.payment.message}` : '';
        showMessage(`Request submitted successfully!${paymentMsg}`, 'success');
        assistForm.reset();
        locationInput.value = '';
        setCoordinateDisplay(null);
        if (cardDetails) cardDetails.style.display = 'none';
        if (pickerMarker) {
          pickerMap.removeLayer(pickerMarker);
          pickerMarker = null;
        }
      } else {
        const errorMsg = result.errors ? result.errors.join(', ') : (result.error || 'Failed to submit request. Please try again.');
        showMessage(errorMsg, 'error');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      showMessage('Network error. Please check your connection and try again.', 'error');
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  }

  // Payment method handling
  const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
  const cardDetails = document.getElementById('cardDetails');
  
  if (paymentMethods.length > 0 && cardDetails) {
    paymentMethods.forEach(method => {
      method.addEventListener('change', (e) => {
        if (e.target.value === 'online') {
          cardDetails.style.display = 'block';
          // Make card fields required
          cardDetails.querySelectorAll('input').forEach(input => {
            input.required = true;
          });
        } else {
          cardDetails.style.display = 'none';
          // Remove required from card fields
          cardDetails.querySelectorAll('input').forEach(input => {
            input.required = false;
            input.value = '';
          });
        }
      });
    });
  }

  // Format card number input
  const cardNumberInput = document.querySelector('input[name="card_number"]');
  if (cardNumberInput) {
    cardNumberInput.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\s/g, '');
      let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
      if (formattedValue.length <= 19) {
        e.target.value = formattedValue;
      }
    });
  }

  // Format expiry date input
  const expiryInput = document.querySelector('input[name="expiry"]');
  if (expiryInput) {
    expiryInput.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\D/g, '');
      if (value.length >= 2) {
        value = value.substring(0, 2) + '/' + value.substring(2, 4);
      }
      e.target.value = value;
    });
  }

  // Format CVV input
  const cvvInput = document.querySelector('input[name="cvv"]');
  if (cvvInput) {
    cvvInput.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/\D/g, '').substring(0, 4);
    });
  }

  // Attach form handler
  if (assistForm) {
    assistForm.addEventListener('submit', submitForm);
  }

  // Only render if we have updated data, otherwise keep server-rendered content
  // This will be called after form submission to update the list
  // Initial page load uses server-rendered content for better performance
})();

