(() => {
  const form = document.getElementById('authForm');
  const userTypeInput = document.getElementById('userType');
  const btnUser = document.getElementById('btnUser');
  const btnWorker = document.getElementById('btnWorker');
  const submitBtn = form.querySelector('button[type="submit"]');

  // User type selection
  [btnUser, btnWorker].forEach(btn => {
    btn.addEventListener('click', () => {
      btnUser.classList.remove('active');
      btnWorker.classList.remove('active');
      btn.classList.add('active');
      userTypeInput.value = btn.getAttribute('data-type');
    });
  });

  // Check URL for user type
  const urlParams = new URLSearchParams(window.location.search);
  const type = urlParams.get('type');
  if (type === 'worker') {
    btnWorker.click();
  }

  // Form submission
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'Processing...';

    try {
      const response = await fetch(form.action || window.location.pathname, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (result.success) {
        if (result.user.type === 'worker') {
          window.location.href = '/worker';
        } else {
          window.location.href = '/';
        }
      } else {
        alert(result.error || 'An error occurred');
        submitBtn.disabled = false;
        submitBtn.textContent = submitBtn.textContent.replace('Processing...', form.querySelector('input[type="hidden"][name="user_type"]').value === 'worker' ? 'Sign In' : 'Sign Up');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Network error. Please try again.');
      submitBtn.disabled = false;
      submitBtn.textContent = submitBtn.textContent.replace('Processing...', 'Sign In');
    }
  });
})();

