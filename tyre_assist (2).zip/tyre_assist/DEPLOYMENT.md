# Deployment Guide - Tyre Assist

## Pre-Deployment Checklist

- [x] Authentication system (Users & Workers)
- [x] Payment gateway integration (Online & Cash)
- [x] AI chatbot (tyreBot)
- [x] Worker dashboard with navigation
- [x] User interface with payment options
- [x] API endpoints documented
- [x] Requirements.txt updated
- [x] Procfile configured
- [x] Runtime.txt specified

## Files Created/Updated

### Backend
- `app.py` - Main Flask application with authentication, payments, and AI
- `requirements.txt` - Python dependencies

### Frontend
- `templates/index.html` - Main user interface
- `templates/worker.html` - Worker dashboard
- `templates/auth.html` - Authentication pages
- `static/main.js` - Main application logic
- `static/worker.js` - Worker dashboard logic
- `static/tyrebot.js` - AI chatbot logic
- `static/auth.js` - Authentication logic
- `static/style.css` - Main styles
- `static/worker.css` - Worker dashboard styles
- `static/auth.css` - Authentication styles

### Data Files (Created at runtime)
- `users.json` - User accounts
- `workers.json` - Worker accounts
- `requests.json` - Assistance requests
- `payments.json` - Payment records

## Deployment Steps

### 1. Heroku Deployment

```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create app
heroku create tyre-assist-app

# Set secret key (optional, auto-generated if not set)
heroku config:set SECRET_KEY=your-secret-key-here

# Deploy
git add .
git commit -m "Deploy Tyre Assist with authentication, payments, and AI"
git push heroku main

# Scale dyno
heroku ps:scale web=1

# Open app
heroku open
```

### 2. Render Deployment

1. Connect your GitHub repository to Render
2. Create a new Web Service
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `gunicorn app:app`
5. Add environment variable: `SECRET_KEY` (optional)
6. Deploy

### 3. Railway Deployment

1. Connect GitHub repository
2. Railway will auto-detect Python
3. Add environment variable: `SECRET_KEY` (optional)
4. Deploy

### 4. Local Production Server

```bash
# Install dependencies
pip install -r requirements.txt

# Run with Gunicorn
gunicorn -b 0.0.0.0:5000 app:app

# Or with Waitress (Windows-friendly)
waitress-serve --host=0.0.0.0 --port=5000 app:app
```

## Environment Variables

- `SECRET_KEY`: Flask session secret (auto-generated if not set)
- `FLASK_DEBUG`: Set to `1`, `true`, or `yes` for debug mode (default: False)

## Testing the Deployment

### 1. Test User Sign Up
- Navigate to `/signup`
- Select "User"
- Create an account
- Verify redirect to home page

### 2. Test Worker Sign Up
- Navigate to `/signup`
- Select "Worker"
- Create an account
- Verify redirect to worker dashboard

### 3. Test Payment
- Sign in as user
- Create a request
- Select "Online Payment"
- Enter card details (test: 4111 1111 1111 1111, 12/25, 123)
- Verify payment processing

### 4. Test tyreBot
- Click the tyreBot chat widget
- Ask questions about services, pricing, payment
- Verify AI responses

### 5. Test Worker Dashboard
- Sign in as worker
- View pending requests
- Accept a request
- Navigate to customer location
- Update request status

## Production Considerations

### Database
- Replace JSON file storage with PostgreSQL or MongoDB
- Use SQLAlchemy or similar ORM
- Implement proper migrations

### Payment Gateway
- Integrate with real payment gateway (Stripe, PayPal, etc.)
- Implement webhook handling
- Add payment receipt generation

### Security
- Use HTTPS in production
- Implement rate limiting
- Add CSRF protection
- Use environment variables for secrets
- Implement proper session management

### AI Chatbot
- Consider integrating with OpenAI API for more advanced responses
- Add conversation history
- Implement intent recognition

### Monitoring
- Add error logging (Sentry, Loggly)
- Implement application monitoring
- Set up alerts for errors

## Support

For issues or questions, refer to:
- `API_DOCUMENTATION.md` - API endpoints
- `README.md` - General documentation

## Post-Deployment

1. Test all features
2. Monitor error logs
3. Set up database backup (if using database)
4. Configure domain and SSL
5. Set up monitoring and alerts

